# CODERHOUSE-29125
Testing automation training

1) Instalar las dependiencias del POM de ser necesario
2) Agregar los drivers necesarios en este folder "/src/main/resources/drivers/"
